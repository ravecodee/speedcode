import Home from './Home';
import Details from './Details';

export {Home, Details};
