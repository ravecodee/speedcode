import Details from './Details';
export default Details;
