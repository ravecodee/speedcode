import ICON_CHEVRON_DOWN from './chevron_down.png';
import ICON_BATHROOM from './bathroom.png';
import ICON_BATHROOM_2 from './bathroom_2.png';
import ICON_BEDROOM from './bedroom.png';
import ICON_BEDROOM_2 from './bedroom_2.png';
import ICON_BELL from './bell.png';
import ICON_FILTER from './filter.png';
import ICON_LOCATION from './location.png';
import ICON_SEARCH from './search.png';
import ICON_CHEVRON_LEFT from './chevron_left.png';
import ICON_BOOKMARK from './bookmark.png';
import ICON_PHONE from './phone.png';
import ICON_CHAT from './chat.png';

export {
  ICON_CHEVRON_DOWN,
  ICON_BATHROOM,
  ICON_BATHROOM_2,
  ICON_BEDROOM,
  ICON_BEDROOM_2,
  ICON_BELL,
  ICON_BOOKMARK,
  ICON_CHAT,
  ICON_CHEVRON_LEFT,
  ICON_FILTER,
  ICON_LOCATION,
  ICON_PHONE,
  ICON_SEARCH,
};
