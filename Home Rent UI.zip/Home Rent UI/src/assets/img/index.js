import PIC_1 from './pic_1.png';
import PIC_2 from './pic_2.png';
import PIC_3 from './pic_3.png';
import PIC_4 from './pic_4.png';
import PIC_5 from './pic_5.png';

import GALLERY_1 from './gallery_1.png';
import GALLERY_2 from './gallery_2.png';
import GALLERY_3 from './gallery_3.png';
import GALLERY_4 from './gallery_4.png';

import AVATAR from './avatar.png';

export {
  PIC_1,
  PIC_2,
  PIC_3,
  PIC_4,
  PIC_5,
  GALLERY_1,
  GALLERY_2,
  GALLERY_3,
  GALLERY_4,
  AVATAR,
};
