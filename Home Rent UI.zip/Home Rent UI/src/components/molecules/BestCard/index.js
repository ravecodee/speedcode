import BestCard from './BestCard';
export default BestCard;
