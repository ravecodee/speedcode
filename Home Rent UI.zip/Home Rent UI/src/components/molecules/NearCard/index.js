import NearCard from './NearCard';
export default NearCard;
